docker build -t hoshinotsuyoshi/hadoop-docker .
