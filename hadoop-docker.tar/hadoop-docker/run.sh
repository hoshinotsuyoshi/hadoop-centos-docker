docker run -t -i --name hadoop --rm hoshinotsuyoshi/hadoop-docker bash
